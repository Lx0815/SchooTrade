create definer = root@localhost view goods_type_view as
select `school_trade`.`enums`.`pk_id`       AS `pk_id`,
       `school_trade`.`enums`.`name`        AS `name`,
       `school_trade`.`enums`.`description` AS `description`,
       `school_trade`.`enums`.`create_time` AS `create_time`,
       `school_trade`.`enums`.`update_time` AS `update_time`
from `school_trade`.`enums`
where ((`school_trade`.`enums`.`pk_id` >= 50) and (`school_trade`.`enums`.`pk_id` <= 149));

-- comment on column goods_type_view.pk_id not supported: id，10-19 为user状态，20-29为user的role，30-39为goods状态，40-49为order状态，50-149为goods.type，150-249为tags

-- comment on column goods_type_view.name not supported: 名称

-- comment on column goods_type_view.description not supported: 描述

-- comment on column goods_type_view.create_time not supported: 创建时间

-- comment on column goods_type_view.update_time not supported: 上次修改时间

