create
    definer = root@localhost function email_by_name(last_name varchar(128)) returns varchar(128)
    comment '根据 last_name 查询 email'
    deterministic
    sql security invoker
    reads sql data
BEGIN
	
	RETURN (SELECT e.email
			FROM employees e
			WHERE e.last_name = last_name);
	
END;

