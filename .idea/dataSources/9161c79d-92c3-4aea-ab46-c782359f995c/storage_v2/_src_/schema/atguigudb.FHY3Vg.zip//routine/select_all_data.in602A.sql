create
    definer = root@localhost procedure select_all_data()
    comment '查询 atguigudb.employees 表中的所有数据'
    sql security invoker
    reads sql data
BEGIN

	SELECT *
	FROM employees;
	
END;

